plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
val verCode = (project.findProperty("verCode") as String?)?.toIntOrNull() ?: 1

android {
    namespace = "com.joyose.tool.admin"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.joyose.tool.admin"
        minSdk = 24
        targetSdk = 34
        versionCode = verCode
        versionName = "1.$verCode"
    }
    signingConfigs {
        create("fixed") {
            storeFile = file("../app/td.keystore")
            storeType = "pkcs12"
            storePassword = "android"
            keyAlias = "td"
            keyPassword = "android"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
